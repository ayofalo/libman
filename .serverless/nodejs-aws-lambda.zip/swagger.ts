// Import necessary modules
import express from "express";
import * as swaggerUi from "swagger-ui-express";
import swaggerJSDoc from "swagger-jsdoc";

// Create Express app
const app = express();

// Swagger options
const options: swaggerJSDoc.Options = {
  definition: {
    openapi: "3.0.0", // Specification (optional, defaults to swagger: '2.0')
    info: {
      title: "Library Management System", // Title (required)
      version: "1.0.0", // Version (required)
      description: "API documentation for LMS", // Description (optional)
    },
  },
  // Paths to files containing OpenAPI definitions
  apis: ["./routes/*.ts"], // Assuming your route files are in a 'routes' directory
};

// Initialize swagger-jsdoc
const swaggerSpec = swaggerJSDoc(options);

// Serve the Swagger UI
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
