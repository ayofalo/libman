import mongoose, { type Document, Schema } from 'mongoose'

export interface User extends Document {
  id: string
  email: string
  password: string
  role: string
  // Add more fields as needed
}

const userSchema = new Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, required: true }
  // Define other fields
})

const User = mongoose.model<User>('User', userSchema)

export { User }
