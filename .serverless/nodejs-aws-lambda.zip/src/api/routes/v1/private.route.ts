import express = require("express");

import { type Router } from "express";

// Import Controllers
// Book Controllers

import { addBook } from "../../controllers/bookController/addBook";
import { updateBook } from "../../controllers/bookController/updateBook";
import { deleteBook } from "../../controllers/bookController/deleteBook";

// Author Controllers
import { getAuthors } from "../../controllers/authorController/getAuthors";

import { addAuthor } from "../../controllers/authorController/addAuthor";
import { updateAuthor } from "../../controllers/authorController/updateAuthor";
import { deleteAuthor } from "../../controllers/authorController/deleteAuthor";

// Borrower Controllers

import { getBorrowers } from "../../controllers/borrowerController/getBorrowers";

import { addBorrower } from "../../controllers/borrowerController/addBorrower";
import { addBookToBorrowed } from "../../controllers/borrowerController/updateBorrower"; // to add books borrowed and delete books borrowed
import { deleteBorrowedBook } from "../../controllers/borrowerController/deleteBorrowedBook";
import { deleteBorrower } from "../../controllers/borrowerController/deleteBorrower";

const privateRouter: Router = express.Router();

/**
 * @swagger
 * /authors/{id}:
 *   get:
 *     summary: Retrieve author by ID
 *     description: Retrieve an author record by their ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the author
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Author found and returned successfully
 *       404:
 *         description: Author not found
 *       500:
 *         description: Internal server error
 */

privateRouter.get("/authors/:id", getAuthors);

/**
 * @swagger
 * /borrowers/{id}:
 *   get:
 *     summary: Retrieve borrower by ID
 *     description: Retrieve a borrower record by their ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the borrower
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Borrower found and returned successfully
 *       404:
 *         description: Borrower not found
 *       500:
 *         description: Internal server error
 */
privateRouter.get("/borrowers/:id", getBorrowers);

/**
 * @swagger
 * /books:
 *   post:
 *     summary: Add a new book
 *     description: Add a new book to the library
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               author:
 *                 type: string
 *     responses:
 *       201:
 *         description: Book created successfully
 *       400:
 *         description: Bad request, missing or invalid data
 *       500:
 *         description: Internal server error
 */

privateRouter.post("/books", addBook);

/**
 * @swagger
 * /authors:
 *   post:
 *     summary: Add a new author
 *     description: Add a new author to the database
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       201:
 *         description: Author created successfully
 *       400:
 *         description: Bad request, missing or invalid data
 *       500:
 *         description: Internal server error
 */
privateRouter.post("/authors", addAuthor);

/**
 * @swagger
 * /borrowers:
 *   post:
 *     summary: Add a new borrower
 *     description: Add a new borrower to the database
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       201:
 *         description: Borrower created successfully
 *       400:
 *         description: Bad request, missing or invalid data
 *       500:
 *         description: Internal server error
 */
privateRouter.post("/borrowers", addBorrower);

/**
 * @swagger
 * /books/{bookId}:
 *   put:
 *     summary: Update a book by ID.
 *     parameters:
 *       - in: path
 *         name: bookId
 *         required: true
 *         description: ID of the book to update.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/definitions/Book'  // Assuming you have a definition for the Book object
 *     responses:
 *       '200':
 *         description: Book updated successfully.
 *       '404':
 *         description: Book not found.
 */
privateRouter.put("/books/:bookId", updateBook);
/**
 * @swagger
 * /authors/{authorId}:
 *   put:
 *     summary: Update an author by ID.
 *     parameters:
 *       - in: path
 *         name: authorId
 *         required: true
 *         description: ID of the author to update.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/definitions/Author'  // Assuming you have a definition for the Author object
 *     responses:
 *       '200':
 *         description: Author updated successfully.
 *       '404':
 *         description: Author not found.
 */
privateRouter.put("/authors/:authorId", updateAuthor);

/**
 * @swagger
 * /borrowers/{borrowerId}:
 *   put:
 *     summary: Add a book to borrowed list for a borrower.
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/definitions/BorrowedBook'  // Assuming you have a definition for the BorrowedBook object
 *     responses:
 *       '200':
 *         description: Book added to borrower's list successfully.
 *       '404':
 *         description: Borrower not found.
 */
privateRouter.put("/borrowers/:borrowerId", addBookToBorrowed);

/**
 * @swagger
 * /books/{bookId}:
 *   delete:
 *     summary: Delete a book by ID.
 *     parameters:
 *       - in: path
 *         name: bookId
 *         required: true
 *         description: ID of the book to delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Book deleted successfully.
 *       '404':
 *         description: Book not found.
 */
privateRouter.delete("/books/:bookId", deleteBook);

/**
 * @swagger
 * /authors/{authorId}:
 *   delete:
 *     summary: Delete an author by ID.
 *     parameters:
 *       - in: path
 *         name: authorId
 *         required: true
 *         description: ID of the author to delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Author deleted successfully.
 *       '404':
 *         description: Author not found.
 */
privateRouter.delete("/authors/:authorId", deleteAuthor);
/**
 * @swagger
 * /borrowers/{borrowerId}:
 *   delete:
 *     summary: Delete a borrower by ID.
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower to delete.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Borrower deleted successfully.
 *       '404':
 *         description: Borrower not found.
 */
privateRouter.delete("/borrowers/:borrowerId", deleteBorrower);

/**
 * @swagger
 * /borrowers/{borrowerId}/books/{bookId}:
 *   delete:
 *     summary: Delete a borrowed book from a borrower's list.
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower.
 *         schema:
 *           type: string
 *       - in: path
 *         name: bookId
 *         required: true
 *         description: ID of the book to delete from the borrower's list.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Borrowed book deleted successfully.
 *       '404':
 *         description: Borrowed book not found.
 */
privateRouter.delete(
  "/borrowers/:borrowerId/books/:bookId",
  deleteBorrowedBook
);

export default privateRouter;
