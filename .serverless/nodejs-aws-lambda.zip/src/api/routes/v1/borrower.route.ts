import express = require("express");

import { type Router } from "express";

import { addBookToBorrowed } from "../../controllers/borrowerController/updateBorrower"; // to add books borrowed and delete books borrowed
import { deleteBorrowedBook } from "../../controllers/borrowerController/deleteBorrowedBook";

const borrowerRouter: Router = express.Router();

/**
 * @swagger
 * /borrowers/{borrowerId}:
 *   put:
 *     summary: Add a book to borrowed list
 *     description: Add a book to the list of books borrowed by a borrower
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower
 *         schema:
 *           type: string
 *       - in: body
 *         name: book
 *         description: Book object to be added to the borrowed list
 *         required: true
 *         schema:
 *           type: object
 *           properties:
 *             title:
 *               type: string
 *             author:
 *               type: string
 *             // Add more properties as needed
 *     responses:
 *       200:
 *         description: Book added successfully to the borrowed list
 *       400:
 *         description: Bad request
 *       500:
 *         description: Internal server error
 */

borrowerRouter.put("/borrowers/:borrowerId", addBookToBorrowed);

/**
 * @swagger
 * /borrowers/{borrowerId}/books/{bookId}:
 *   delete:
 *     summary: Delete a borrowed book
 *     description: Delete a book from the list of books borrowed by a borrower
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower
 *         schema:
 *           type: string
 *       - in: path
 *         name: bookId
 *         required: true
 *         description: ID of the book to be deleted from borrowed list
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Book deleted successfully from the borrowed list
 *       404:
 *         description: Book not found
 *       500:
 *         description: Internal server error
 */
borrowerRouter.delete(
  "/borrowers/:borrowerId/books/:bookId",
  deleteBorrowedBook
);

export default borrowerRouter;
