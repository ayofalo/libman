import express = require("express");

import { type Router } from "express";

// Import Controllers
// Book Controllers

import { retrieveBook } from "../../controllers/bookController/retrieveBook";

// Author Controllers

import { retrieveAuthor } from "../../controllers/authorController/retrieveAuthor";
import { getBooksByAuthorId } from "../../controllers/bookController/getBooks";

// Borrower Controllers

import { retrieveBorrowers } from "../../controllers/borrowerController/retrieveBorrower";
import { getBorrowedBooksByBorrower } from "../../controllers/borrowerController/getBorrowedBooksByBorrower";

const publicRouter: Router = express.Router();

/**
 * @swagger
 * /books/{authorId}:
 *   get:
 *     summary: Retrieve books by author ID.
 *     parameters:
 *       - in: path
 *         name: authorId
 *         required: true
 *         description: ID of the author whose books to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Books retrieved successfully.
 *       '404':
 *         description: Author not found or no books found for the author.
 */

publicRouter.get("/books/:authorId", getBooksByAuthorId);

/**
 * @swagger
 * /books:
 *   get:
 *     summary: Retrieve all books.
 *     responses:
 *       '200':
 *         description: Books retrieved successfully.
 *       '404':
 *         description: No books found.
 */
publicRouter.get("/books", retrieveBook);

/**
 * @swagger
 * /authors:
 *   get:
 *     summary: Retrieve all authors.
 *     responses:
 *       '200':
 *         description: Authors retrieved successfully.
 *       '404':
 *         description: No authors found.
 */

publicRouter.get("/authors", retrieveAuthor);
/**
 * @swagger
 * /borrowers:
 *   get:
 *     summary: Retrieve all borrowers.
 *     responses:
 *       '200':
 *         description: Borrowers retrieved successfully.
 *       '404':
 *         description: No borrowers found.
 */
publicRouter.get("/borrowers", retrieveBorrowers);

/**
 * @swagger
 * /{borrowerId}/borrowed-books:
 *   get:
 *     summary: Retrieve borrowed books by borrower ID.
 *     parameters:
 *       - in: path
 *         name: borrowerId
 *         required: true
 *         description: ID of the borrower whose borrowed books to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Borrowed books retrieved successfully.
 *       '404':
 *         description: Borrower not found or no books borrowed by the borrower.
 */

publicRouter.get("/:borrowerId/borrowed-books", getBorrowedBooksByBorrower);

export default publicRouter;
