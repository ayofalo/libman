import express = require("express");
const serverless = require("serverless-http");
import { Request, Response, NextFunction } from "express";
import * as mongoose from "mongoose";
import cors = require("cors");
import * as dotenv from "dotenv";
import * as winston from "winston";
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

import * as bodyParser from "body-parser";
import authenticateUser from "./api/middleware/authenticateToken";
import { authorizeUser } from "./api/middleware/autorizeUser";
import privateRouter from "./api/routes/v1/private.route";
import publicRouter from "./api/routes/v1/public.routes";
import borrowerRouter from "./api/routes/v1/borrower.route";
import userRouter from "./api/routes/v1/user.routes";

dotenv.config();

const app = express();

// CORS
app.use(cors());
// CORS headers
app.use((req: Request, res: Response, next: NextFunction) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

// Use cookie-parser middleware
app.use(cookieParser());
// Body parser
app.use(express.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "100mb", extended: true }));
// Request logging middleware

app.use(morgan("combined")); // Use 'combined' format for logging

// Routes
app.use("/api/auth", userRouter);
app.use("/api/public", publicRouter);
app.use("/api/private/admin", authorizeUser, authenticateUser, privateRouter); //routes onlu admin can function
app.use("/api/private/borrower", borrowerRouter);

// Catch-all route handler for any other routes
app.use((req: Request, res: Response) => {
  res.status(404).send("Route not found");
});

// Logger
const logger = winston.createLogger({
  level: "info",
  format: winston.format.simple(),
  transports: [new winston.transports.Console()],
});

// Database connection
const db = process.env.MONGO_URI as string; // Use the environment variable for MongoDB URI
mongoose
  .connect(db)
  .then(() => {
    logger.info("MongoDB connected...");
  })
  .catch((error: any) => {
    logger.error(error);
  });

const port = process.env.PORT || 3001;
app.listen(port, () => logger.info(`Server started on port ${port}`));

export default app;

module.exports.handler = serverless(app);
